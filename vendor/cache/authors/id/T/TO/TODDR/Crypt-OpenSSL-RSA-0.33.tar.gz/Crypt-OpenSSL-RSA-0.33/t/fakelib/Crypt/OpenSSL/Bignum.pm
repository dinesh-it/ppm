package Crypt::OpenSSL::Bignum;

0;    # make require fail
