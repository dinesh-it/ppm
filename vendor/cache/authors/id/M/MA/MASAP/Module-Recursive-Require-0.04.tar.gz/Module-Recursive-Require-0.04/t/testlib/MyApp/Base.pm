package MyApp::Base;

use strict;
use warnings;

sub hoge {
    return "hoge";
}

1;

=head1 NAME

MyApp::Base - Test Base Class ( DUMMY!! )

=cut
