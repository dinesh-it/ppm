package MyApp::Test;

use strict;

print "test!\n";

1;
