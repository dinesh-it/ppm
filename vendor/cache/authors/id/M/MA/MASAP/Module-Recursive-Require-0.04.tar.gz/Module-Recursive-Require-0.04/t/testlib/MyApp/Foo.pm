package MyApp::Foo;

use strict;
use warnings;
use base qw/MyApp::Base/;


1;
