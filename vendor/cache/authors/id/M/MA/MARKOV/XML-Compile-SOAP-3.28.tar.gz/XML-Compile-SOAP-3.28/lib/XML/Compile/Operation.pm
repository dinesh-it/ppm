# Copyrights 2007-2022 by [Mark Overmeer <markov@cpan.org>].
#  For other contributors see ChangeLog.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.03.

   die "XML::Compile::Operation got renamed into XML::Compile::SOAP::Operation n release 2.18";
   1;
