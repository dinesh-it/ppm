package TestApp::View::Download;

use FindBin;
use lib "$FindBin::Bin/../../../../lib";
use lib "$FindBin::Bin/../../../lib";
use base 'Catalyst::View::Download';

1;
