package TestApp::View::Download::XML;

use FindBin;
use lib "$FindBin::Bin/../../../../../lib";
use lib "$FindBin::Bin/../../../../lib";
use base 'Catalyst::View::Download::XML';

1;
