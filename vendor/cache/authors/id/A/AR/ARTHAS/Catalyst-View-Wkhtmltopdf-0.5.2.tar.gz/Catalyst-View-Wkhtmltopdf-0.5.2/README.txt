Catalyst::View::Wkhtmltopdf
---------------------------

Catalyst view to convert HTML (or TT) content to PDF using wkhtmltopdf.

TODO:

- WRITE TESTS!!!!
- Use pipes (IPC::Open2) instead of temp files, maybe 
- Add more configuration options
