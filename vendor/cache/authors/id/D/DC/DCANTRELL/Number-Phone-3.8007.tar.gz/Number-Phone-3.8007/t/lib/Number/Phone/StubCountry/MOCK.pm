package Number::Phone::StubCountry::MOCK;
use base qw(Number::Phone::StubCountry::GB);
1;
