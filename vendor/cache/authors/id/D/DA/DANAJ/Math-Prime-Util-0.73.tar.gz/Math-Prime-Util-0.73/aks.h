#ifndef MPU_AKS_H
#define MPU_AKS_H

#include "ptypes.h"

extern int is_aks_prime(UV n);

#endif
