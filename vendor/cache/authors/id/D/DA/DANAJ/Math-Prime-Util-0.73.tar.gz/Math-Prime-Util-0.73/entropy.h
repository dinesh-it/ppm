#ifndef MPU_ENTROPY_H
#define MPU_ENTROPY_H

#include "ptypes.h"

extern UV get_entropy_bytes(UV bytes, unsigned char* buf);

#endif
