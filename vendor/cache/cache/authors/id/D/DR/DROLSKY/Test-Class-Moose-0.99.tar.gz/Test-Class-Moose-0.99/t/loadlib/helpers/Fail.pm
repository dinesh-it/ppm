package Fail;

use strict;
use warnings;

intentional syntax error goes here;

1;
