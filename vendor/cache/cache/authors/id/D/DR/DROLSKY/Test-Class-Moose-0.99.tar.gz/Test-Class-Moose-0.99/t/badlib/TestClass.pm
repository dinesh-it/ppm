package TestClass;

use strict;
use warnings;
use namespace::autoclean;

# This base class is just fine.

use Test::Class::Moose;

1;
