package LoadTests::Success;

use strict;
use warnings;
use namespace::autoclean;

use Fail;

1;
