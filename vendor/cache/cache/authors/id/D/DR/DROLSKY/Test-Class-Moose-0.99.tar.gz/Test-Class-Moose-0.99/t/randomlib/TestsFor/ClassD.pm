package ClassD;

use strict;
use warnings;
use namespace::autoclean;

use Test::Class::Moose;

sub test_d {
    ok( 1, 'package D' );
}

1;
