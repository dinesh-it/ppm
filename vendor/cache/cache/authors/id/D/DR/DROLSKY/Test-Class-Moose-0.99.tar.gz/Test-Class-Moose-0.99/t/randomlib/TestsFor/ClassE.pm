package ClassE;

use strict;
use warnings;
use namespace::autoclean;

use Test::Class::Moose;

sub test_e {
    ok( 1, 'package E' );
}

1;
