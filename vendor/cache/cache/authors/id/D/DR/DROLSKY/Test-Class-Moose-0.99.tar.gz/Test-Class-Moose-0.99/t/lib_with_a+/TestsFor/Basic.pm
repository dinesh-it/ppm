package TestsFor::Basic;

use strict;
use warnings;
use namespace::autoclean;

use Test::Class::Moose;

sub test_basic {
    ok( 1, 'test ran' );
}

1;
