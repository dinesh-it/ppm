package TestsFor::Pass;

use strict;
use warnings;
use namespace::autoclean;

use Test::Class::Moose;

sub test_a_good {
    ok 1;
}

sub test_a_good_2 {
    ok 1;
}

sub test_b_good {
    ok 1;
}

sub test_b_good_2 {
    ok 1;
}

1;
