use strict;

package HTML::FormFu::Constraint::MinRange;
$HTML::FormFu::Constraint::MinRange::VERSION = '2.07';
# ABSTRACT: Minimum Value Constraint

use Moose;
extends 'HTML::FormFu::Constraint::Range';

sub _localize_args {
    my ($self) = @_;

    return $self->min;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

HTML::FormFu::Constraint::MinRange - Minimum Value Constraint

=head1 VERSION

version 2.07

=head1 DESCRIPTION

Checks the input value is equal to or greater than a minimum value.

Overrides L<HTML::FormFu::Constraint/localize_args>, so that the value of
L</minimum> is passed as an argument to L<localize|HTML::FormFu/localize>.

This constraint doesn't honour the C<not()> value.

=head1 METHODS

=head2 minimum

=head2 min

The minimum input value.

L</min> is an alias for L</minimum>.

=head1 SEE ALSO

Is a sub-class of, and inherits methods from
L<HTML::FormFu::Constraint::Range>, L<HTML::FormFu::Constraint>

L<HTML::FormFu>

=head1 AUTHOR

Carl Franks C<cfranks@cpan.org>

=head1 LICENSE

This library is free software, you can redistribute it and/or modify it under
the same terms as Perl itself.

=head1 AUTHOR

Carl Franks <cpan@fireartist.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2018 by Carl Franks.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
