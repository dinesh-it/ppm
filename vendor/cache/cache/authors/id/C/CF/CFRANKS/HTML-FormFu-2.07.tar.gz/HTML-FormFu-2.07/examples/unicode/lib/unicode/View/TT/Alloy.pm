package unicode::View::TT::Alloy;

use strict;
use base 'Catalyst::View::TT::Alloy';

1;

