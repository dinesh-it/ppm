CREATE TABLE `unicode` (
`id` INTEGER PRIMARY KEY NOT NULL,
`string` VARCHAR(255)
);

INSERT INTO `unicode` (`id`, `string`) VALUES (1, 'Ungültig');
