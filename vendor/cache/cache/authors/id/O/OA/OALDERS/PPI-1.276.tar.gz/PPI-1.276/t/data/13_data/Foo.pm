package Foo;

print "Hello World!\n";

__DATA__
This is data
So is this
