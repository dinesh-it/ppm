# Contributing

The best was to contribute is to fork https://github.com/timlegge/perl-Crypt-OpenSSL-Verify and send a pull request.

I am fine with issues reported as a [Github Issue](https://github.com/timlegge/perl-Crypt-OpenSSL-Verify/issues) (Prefered) or at [Request Tracker](https://rt.cpan.org/Dist/Display.html?Name=Crypt-OpenSSL-Verify) if you prefer.

I will likely close issues at Request Tracker and provide a link to a Github issue.
