package Req2; {
   use Object::InsideOut 'Req1';
}
1;
