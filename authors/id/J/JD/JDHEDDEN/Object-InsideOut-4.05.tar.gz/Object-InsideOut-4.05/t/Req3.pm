package Req3; {
   use Object::InsideOut qw(Req2 Req4);
}
1;
