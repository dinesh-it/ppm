package TestApp;

use base qw ( Catalyst );
use Catalyst qw ( ConfigLoader );
use strict;
use warnings;

__PACKAGE__->setup();

1;
