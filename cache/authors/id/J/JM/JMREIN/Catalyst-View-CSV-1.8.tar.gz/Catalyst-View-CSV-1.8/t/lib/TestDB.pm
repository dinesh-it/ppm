package TestDB;

use base qw ( DBIx::Class::Schema );
use strict;
use warnings;

__PACKAGE__->load_namespaces();

1;
