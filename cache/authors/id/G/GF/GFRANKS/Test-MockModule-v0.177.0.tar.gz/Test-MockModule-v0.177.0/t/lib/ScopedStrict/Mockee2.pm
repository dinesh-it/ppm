package ScopedStrict::Mockee2;

use strict;
use warnings;

sub also_gonna_mock_this { return "you're not going to see this either" }

1;
