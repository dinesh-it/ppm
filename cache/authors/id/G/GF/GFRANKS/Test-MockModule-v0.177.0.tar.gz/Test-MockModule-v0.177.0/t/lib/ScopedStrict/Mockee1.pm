package ScopedStrict::Mockee1;

use strict;
use warnings;

sub gonna_mock_this { return "you're not going to see this" }

1;
