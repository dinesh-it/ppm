package Foo::Baz;
sub mvp_multivalue_args { qw(multi) }

1;
