package Devel::Deprecations::Environmental::Plugin::Internal::Broken;

use strict;
use warnings;

1;
