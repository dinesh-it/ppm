#!/usr/bin/bash
# HARNESS-DURATION-SHORT
echo "ok 1";
echo "1..1";
exit 0;
