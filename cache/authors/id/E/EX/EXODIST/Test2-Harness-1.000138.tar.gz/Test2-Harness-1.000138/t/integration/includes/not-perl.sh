#!/usr/bin/env bash
exec $YATH_PERL not-perl.pl
