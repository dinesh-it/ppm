die "Loaded Bar.pm from the wrong project!";
