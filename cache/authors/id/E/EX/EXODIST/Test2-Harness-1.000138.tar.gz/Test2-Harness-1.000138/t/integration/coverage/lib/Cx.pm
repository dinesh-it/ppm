package Cx;
use strict;
use warnings;

sub c { 'c' }

1;
