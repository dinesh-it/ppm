use strict;
use warnings;

sub file_loaded { 1 }

is(__PACKAGE__, 'main', "in main package");

1;
