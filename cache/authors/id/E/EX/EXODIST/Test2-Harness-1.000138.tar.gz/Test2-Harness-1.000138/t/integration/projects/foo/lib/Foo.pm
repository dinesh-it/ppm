package Foo;

1;
