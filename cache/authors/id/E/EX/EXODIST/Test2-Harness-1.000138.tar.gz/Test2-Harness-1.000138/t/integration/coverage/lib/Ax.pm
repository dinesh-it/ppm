package Ax;
use strict;
use warnings;

# This is here for simulating a non-sub change
my $A = 'a';

sub a { 'a' }
sub aa { 'aa' }

1;
