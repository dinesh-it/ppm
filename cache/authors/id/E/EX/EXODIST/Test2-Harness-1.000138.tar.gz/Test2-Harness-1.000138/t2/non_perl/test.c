#include <stdio.h>
int main() {
    printf("ok 1 - assertion\n");
    printf("1..1\n");
    return 0;
}
