package Broken;

die "This is broken";
