package Bx;
use strict;
use warnings;

sub b { 'b' }

1;
