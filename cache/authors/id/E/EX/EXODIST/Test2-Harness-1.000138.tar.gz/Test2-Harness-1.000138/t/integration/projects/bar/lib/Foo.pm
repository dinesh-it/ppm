die "Loaded Foo.pm from the wrong project!";
