package App::Yath::Command::Broken;

die "This command is broken!";
